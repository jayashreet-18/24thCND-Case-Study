const config={
    secret: "organic"
}

module.exports=config;